# FloFit Spring Boot Backend

Requires Java 21 and Maven 3.9+.

Run locally: `mvn spring-boot:run`

Health check: `http://localhost:8080/api/health`

Build: `mvn clean package`

For deployment, configure PostgreSQL environment variables `SPRING_DATASOURCE_URL`, `SPRING_DATASOURCE_USERNAME`, `SPRING_DATASOURCE_PASSWORD`, and `SPRING_DATASOURCE_DRIVER=org.postgresql.Driver`; set `SPRING_PROFILES_ACTIVE=postgres` if using `application-postgres.properties`. Configure `FLOFIT_CORS_ORIGINS` with your frontend origin. This MVP does not have authentication; do not use real health data publicly until authentication and access controls are added.
